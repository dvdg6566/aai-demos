def lambda_handler(event, context):
	return 'Homepage Lambda running successfully!'

if __name__ == '__main__':
	lambda_handler(None,None)